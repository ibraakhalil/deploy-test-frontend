import urlJoin from "proper-url-join";

export const joinUrl = urlJoin;
