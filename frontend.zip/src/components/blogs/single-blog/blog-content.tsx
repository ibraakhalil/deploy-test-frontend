export function BlogContent() {
  return (
    <div className="space-y-6">
      <p className="text-body text-subtitle-color">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. In eget sapien vel velit tincidunt posuere. Donec vitae
        dolor nec nunc fermentum fringilla. Nulla facilisi. Sed nec eros tristique, interdum nunc id, ultricies quam.
        Sed vel eros nec nunc fermentum fringilla. Nulla facilisi. Sed nec eros tristique, interdum nunc id, ultricies
        quam. Sed vel eros nec nunc fermentum fringilla. Nulla facilisi. Sed nec eros tristique, interdum nunc id,
        ultricies quam.
      </p>
      <p className="text-body text-subtitle-color">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. In eget sapien vel velit tincidunt posuere. Donec vitae
        dolor nec nunc fermentum fringilla. Nulla facilisi. Sed nec eros tristique, interdum nunc id, ultricies quam.
        Sed vel eros nec nunc fermentum fringilla. Nulla facilisi. Sed nec eros tristique, interdum nunc id, ultricies
        quam. Sed vel eros nec nunc fermentum fringilla. Nulla facilisi. Sed nec eros tristique, interdum nunc id,
        ultricies quam.
      </p>
      <p className="text-body text-subtitle-color">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. In eget sapien vel velit tincidunt posuere. Donec vitae
        dolor nec nunc fermentum fringilla. Nulla facilisi. Sed nec eros tristique, interdum nunc id, ultricies quam.
        Sed vel eros nec nunc fermentum fringilla. Nulla facilisi. Sed nec eros tristique, interdum nunc id, ultricies
        quam. Sed vel eros nec nunc fermentum fringilla. Nulla facilisi. Sed nec eros tristique, interdum nunc id,
        ultricies quam.
      </p>
    </div>
  );
}
