export function ChapterCollection() {
  return <div>Chapter Collection</div>;
}
