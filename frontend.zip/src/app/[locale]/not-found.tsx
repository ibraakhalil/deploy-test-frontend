export default function NotFound() {
  return <div>Not found</div>;
}
