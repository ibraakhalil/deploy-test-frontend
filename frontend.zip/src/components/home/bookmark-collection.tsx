export function BookmarkCollection() {
  return <div>Bookmark Collection</div>;
}
