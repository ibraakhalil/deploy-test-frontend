export const BOOKMARK_COLORS = [
  "#5EAF7F",
  "#F2CA54",
  "#DD71DF",
  "#63AFEB",
  "#EE588B",
  "#7281D6",
  "#4FBFCD",
  "#90C256",
  "#F69374",
];
